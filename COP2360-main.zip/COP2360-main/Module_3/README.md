Creating Types in C#

The following .txt files have C# code snippets corresponding to each section in chapter 3
  1. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/Classes.txt
  2. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/Inheritance.txt
  3. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/The_object_Type.txt
  4. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/Structs.txt
  5. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/Access_Modifiers.txt
  6. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/Interfaces.txt
  7. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/Enums.txt
  8. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/Nested_Types.txt
  9. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_3/Generics.txt

