# Module 2: Using Data


In this Module, we introduce the basics of the C# language. Keep in mind that these concepts are the FOUNDATION for all of theother concepts that will be covered in this course so we will take a bit longer to go through this Module.

## A First C# Program

  A method performs a function (in some languages the term function is used, they are interchangeable for the contect of this course); a Method is often referred to as an algorithm;  a class groups function members and data members to form an object-oriented building block. The Console class groups members that handle command-line input/output (I/O) functionality, such as the WriteLine method. A class is a kind of type, which we examine later.

  1. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_2/2_0.cs
  2. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_2/2_1.cs
  3. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_2/2_2.cs
  4. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_2/2_3.cs
  5. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_2/2_4.cs
  6. https://github.com/PBSC-Hammond/COP2360/blob/main/Module_2/2_5.cs
## Syntax
## Type Basics
## Numeric Types
## Boolean Type and Operators
## Strings and Characters
## Arrays
## Multidimensional Arrays
## Variables and Parameters
## Expressions and Operators
## Namespaces
