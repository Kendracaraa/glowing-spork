int x = 12 * 30;                // Statement 1
System.Console.WriteLine (x);   // Statement 2
