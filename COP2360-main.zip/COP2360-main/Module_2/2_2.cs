SayHello();

void SayHello()
{
  Console.WriteLine ("Hello, world");
